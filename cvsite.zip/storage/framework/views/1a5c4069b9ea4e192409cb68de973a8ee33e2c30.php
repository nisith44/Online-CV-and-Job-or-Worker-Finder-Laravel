<?php $__env->startSection('title', $userdata->full_name); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <!-- side bar -->
        <div class="col-md-3">
            <a href="/edit-profile" class="btn btn-primary btn-lg btn-block">UPDATE PROFILE</a href="/edit-profile">
            <br>
            <div class="card border-dark">
                <img src="<?php echo e(asset('storage/propics/'.$userdata->propic)); ?>" class="card-img-top " alt="...">
                <div class="card-body">
                    <h5 class="card-title"><?php echo e($userdata->full_name); ?></h5>
                    <p class="card-text"><b>Contact Information</b>
                        <br> <i class="fas fa-phone-alt"></i> <?php echo e($userdata->tel); ?>

                        <br> <i class="fas fa-envelope"></i> <?php echo e($userdata->email); ?>

                        <br> <i class="fas fa-map-marker-alt"></i> <?php echo e($userdata->address); ?> </p>
                    <!-- <a href="#" class="btn btn-primary">Go somewhere</a> -->
                    <!-- AddToAny BEGIN -->
                    <div class="a2a_kit a2a_kit_size_32 a2a_default_style">
                        <a class="a2a_dd" href="https://www.addtoany.com/share"></a>
                        <a class="a2a_button_facebook"></a>
                        <a class="a2a_button_whatsapp"></a>
                        <a class="a2a_button_twitter"></a>
                        <a class="a2a_button_email"></a> 
                        <a style="margin-top:10px;" class="a2a_button_google_gmail"></a>
                        <a style="margin-top:10px;" class="a2a_button_sms"></a>
                    </div>
                    <script async src="https://static.addtoany.com/menu/page.js"></script>
                    <!-- AddToAny END -->
                </div>
            </div>
            <br>
            <div class="card text-white bg-dark mb-3" style="">
                <div class="card-header">
                    <h5 class="card-title">MY SKILLS</h5>
                </div>
                <div class="card-body">

                    <?php $__currentLoopData = $skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p class="card-text"><i class="fas fa-check"></i> <?php echo e($skill->skill); ?> </p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
        </div>
        <!-- side bar end -->



        <div class="col-md-9">



            <?php if($userdata->id==Auth::id()): ?>

            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong><?php echo e($userdata->pageviews); ?></strong> People Seen your CV profile
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <?php endif; ?>


            <div class="card border-dark">
                <h5 class="card-header"><i class="far fa-user-circle"></i> Personal Information</h5>
                <div class="card-body">
                    <?php $__currentLoopData = $personalinfos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $personalinfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <h5 class="card-title"><i class="fas fa-chevron-circle-right fa-lg text-primary"></i>
                        <?php echo e($personalinfo->title); ?></h5>
                    <p class="card-text"><?php echo $personalinfo->description ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div><br>

            <div class="card border-dark">
                <h5 class="card-header"><i class="fas fa-graduation-cap"></i> Educational Information</h5>
                <div class="card-body">
                    <?php $__currentLoopData = $eduinfos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eduinfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <h5 class="card-title"><i class="fas fa-chevron-circle-right fa-lg text-primary"></i>
                        <?php echo e($eduinfo->title); ?></h5>
                    <p class="card-text"><?php echo $eduinfo->description ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div><br>

            <div class="card border-dark">
                <h5 class="card-header"><i class="fas fa-user-tie"></i> Professional qualifications</h5>
                <div class="card-body">
                    <?php $__currentLoopData = $proinfos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proinfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <h5 class="card-title"><i class="fas fa-chevron-circle-right fa-lg text-primary"></i>
                        <?php echo e($proinfo->title); ?></h5>
                    <p class="card-text"><?php echo $proinfo->description ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div><br>


            <div class="card border-dark">
                <h5 class="card-header"><i class="fas fa-briefcase"></i> Working Experience</h5>
                <div class="card-body">
                    <?php $__currentLoopData = $works; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $work): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <h5 class="card-title"><i class="fas fa-chevron-circle-right fa-lg text-primary"></i>
                        <?php echo e($work->title); ?></h5>
                    <p class="card-text"><?php echo $work->description ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div><br>


            <div class="card border-dark">
                <h5 class="card-header"><i class="fas fa-rocket"></i> Already Did Projects</h5>
                <div class="card-body">
                    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <h5 class="card-title"><i class="fas fa-chevron-circle-right fa-lg text-primary"></i>
                        <?php echo e($project->title); ?></h5>
                    <p class="card-text"><?php echo $project->description ?></p>
                    Download : <a target="_blank" href="<?php echo e($project->url); ?>"><?php echo e($project->url); ?></a> <br><br>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div><br>


        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>